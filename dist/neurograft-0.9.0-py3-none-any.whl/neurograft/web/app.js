const $ = (id) => document.getElementById(id);
const TEST_MODE = new URLSearchParams(location.search).get('test') === '1';
const SOURCE_KEYS = ['worm', 'fly_f', 'fly_m', 'human'];
const SOURCE_LABELS = ['Worm', 'Fly ♀', 'Fly ♂', 'Human'];
const SOURCE_COLORS = ['#5ee9ce', '#69b5ff', '#ad9af6', '#eda879'];
const BEACON_COLORS = { blue: '#69b5ff', amber: '#f5be66', rose: '#ed85ae' };
const DIRECTION_NAMES = ['north', 'east', 'south', 'west'];
let session = null;
let writeInFlight = false;
let pollInFlight = false;
let generation = 0;
let lastSuccessful = 0;
let networkError = false;
let lastChat = '';
let lastFacts = '';
let lastCheckpoints = '';
let toastTimer;
let evaluationReport = null;
let evaluationInFlight = false;
let evaluationStarted = 0;
let evaluationError = '';
let renderedEvaluation = null;
let THREE, renderer, scene, camera, worldGroup, wallGroup, beaconGroup, agentGroup, goalGroup, trailLine;
let floorMesh, raycaster, pointerVector;
let renderedWorldKey = '';
let webglReady = false;
let webglError = null;
let sceneDirty = true;
let worldSize = 11;
let lastWorldVisualKey = '';
const beaconPickables = [];
const agentTarget = { x: 0, z: 0, angle: 0 };
const orbit = { theta: 0.67, phi: 0.75, radius: 20.5, targetX: 0, targetZ: 0 };
const pointer = { down: false, x: 0, y: 0, startX: 0, startY: 0, dragged: false, id: null };
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;

const formatNumber = (value, decimals = 0) => Number.isFinite(Number(value)) ? Number(value).toLocaleString(undefined, { maximumFractionDigits: decimals, minimumFractionDigits: decimals }) : '—';
const finite = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const clip = (value, low, high) => Math.max(low, Math.min(high, value));

function showError(message) {
  $('error-message').textContent = String(message);
  $('error-banner').hidden = false;
}

function showToast(message) {
  clearTimeout(toastTimer);
  $('toast').textContent = message;
  $('toast').hidden = false;
  toastTimer = setTimeout(() => { $('toast').hidden = true; }, 3500);
}

class APIError extends Error {
  constructor(message, status = 0) { super(message); this.status = status; }
}

async function fetchJSON(path, payload, timeoutMs = payload ? 20000 : 7000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(path, {
      method: payload ? 'POST' : 'GET',
      headers: payload ? { 'Content-Type': 'application/json' } : { Accept: 'application/json' },
      body: payload ? JSON.stringify(payload) : undefined,
      signal: controller.signal,
      cache: 'no-store',
      credentials: 'same-origin',
    });
    let data;
    try { data = await response.json(); }
    catch { throw new APIError(`The local server returned an unreadable response (${response.status}).`, response.status); }
    if (!response.ok) throw new APIError(data.error || `Request failed (${response.status}).`, response.status);
    return data;
  } catch (error) {
    if (error.name === 'AbortError') throw new APIError('The local server did not respond in time. The last received state is still shown.');
    if (error instanceof APIError) throw error;
    throw new APIError('Cannot reach the local session. Keep the Python live service running; this view will reconnect automatically.');
  } finally { clearTimeout(timeout); }
}

function isStale() { return !lastSuccessful || Date.now() - lastSuccessful > 8000; }

function updateConnectivity() {
  const stale = isStale();
  const indicator = $('connection-status');
  indicator.className = `connection ${networkError ? 'offline' : stale && lastSuccessful ? 'stale' : lastSuccessful ? 'online' : ''}`;
  $('connection-label').textContent = networkError ? 'Disconnected · retrying' : stale && lastSuccessful ? 'State is stale' : lastSuccessful ? 'Local session connected' : 'Connecting';
  if (session) {
    $('scene-state').textContent = networkError ? 'DISCONNECTED · LAST RECEIVED WORLD' : stale ? 'STALE · LAST RECEIVED WORLD' : session.running ? 'LIVE · SERVER CONTROLLED' : 'PAUSED · MANUAL CONTROL';
    $('run-state').textContent = writeInFlight ? 'Updating session…' : networkError ? 'Session disconnected' : stale ? 'Awaiting fresh state' : session.running ? '● Session running' : 'Ⅱ Session paused';
  }
  updateControls();
}

function updateControls() {
  const unavailable = writeInFlight || !session || networkError || isStale();
  document.querySelectorAll('[data-write]').forEach((el) => { el.disabled = unavailable; });
  $('chat-input').disabled = unavailable;
  $('step-btn').disabled = unavailable || Boolean(session?.running);
  $('pause-btn').hidden = Boolean(session && !session.running);
  $('resume-btn').hidden = !session || Boolean(session.running);
  $('chat-send').disabled = unavailable || !$('chat-input').value.trim();
  document.querySelectorAll('.example-chip').forEach((el) => { el.disabled = unavailable; });
  if (session && !writeInFlight) $('learning-toggle').checked = Boolean(session.learning);
  if (session && !writeInFlight) $('navigation-mode').value = session.navigation?.mode || 'policy';
  $('evaluate-btn').disabled = unavailable || evaluationInFlight;
  $('export-evaluation-btn').disabled = !evaluationReport;
}

function applySnapshot(incoming) {
  if (!incoming || typeof incoming !== 'object' || !incoming.world || !incoming.world.agent) throw new APIError('The local server returned an incomplete session snapshot.');
  session = { ...incoming, runtime: incoming.runtime ?? session?.runtime, checkpoints: incoming.checkpoints ?? session?.checkpoints ?? [] };
  lastSuccessful = Date.now();
  networkError = false;
  renderSession();
  updateConnectivity();
}

async function poll() {
  if (!pollInFlight && !writeInFlight) {
    pollInFlight = true;
    const startedAtGeneration = generation;
    try {
      const state = await fetchJSON('/api/state');
      // A read begun before a mutation must never replace its newer response.
      if (!writeInFlight && startedAtGeneration === generation) applySnapshot(state);
    } catch (error) {
      if (!writeInFlight && startedAtGeneration === generation) {
        networkError = true;
        if (!session) {
          $('scene-loading').querySelector('strong').textContent = 'Waiting for the local service';
          $('scene-loading').querySelector('span:last-child').textContent = error.message;
        }
        updateConnectivity();
      }
    } finally { pollInFlight = false; }
  }
  setTimeout(poll, 500);
}

async function mutate(path, payload) {
  if (writeInFlight) return null;
  const focused = document.activeElement;
  writeInFlight = true;
  generation += 1;
  updateConnectivity();
  try {
    const result = await fetchJSON(path, payload);
    applySnapshot(result.state || result);
    return result;
  } catch (error) {
    showError(error.message);
    if (!error.status) networkError = true;
    return null;
  } finally {
    writeInFlight = false;
    generation += 1;
    updateConnectivity();
    if (focused && focused !== document.body && focused.isConnected && !focused.disabled && !focused.hidden && document.activeElement === document.body) {
      focused.focus({ preventScroll: true });
    }
  }
}

function control(payload) { return mutate('/api/control', payload); }

function makeSourceRows() {
  SOURCE_KEYS.forEach((key, index) => {
    const row = document.createElement('div');
    row.className = 'source-row';
    row.style.setProperty('--source-color', SOURCE_COLORS[index]);
    const icon = document.createElement('span');
    icon.className = 'source-icon';
    icon.textContent = ['C', 'F', 'M', 'H'][index];
    const copy = document.createElement('div');
    const title = document.createElement('div');
    title.className = 'source-title';
    const name = document.createElement('span');
    name.textContent = SOURCE_LABELS[index];
    const badge = document.createElement('span');
    badge.id = `source-${key}-badge`;
    badge.className = 'source-badge';
    badge.textContent = 'pending';
    title.append(name, badge);
    const detail = document.createElement('div');
    detail.id = `source-${key}-detail`;
    detail.className = 'source-detail';
    detail.textContent = 'Awaiting graph';
    const nodes = document.createElement('div');
    nodes.id = `source-${key}-nodes`;
    nodes.className = 'source-nodes';
    nodes.textContent = 'Top firing: —';
    copy.append(title, detail, nodes);
    const activity = document.createElement('div');
    activity.className = 'activity-value';
    const value = document.createElement('span');
    value.id = `source-${key}-activity`;
    value.textContent = '—';
    const track = document.createElement('div');
    track.className = 'activity-track';
    const bar = document.createElement('div');
    bar.className = 'activity-bar';
    bar.id = `source-${key}-bar`;
    track.append(bar);
    activity.append(value, track);
    row.append(icon, copy, activity);
    $('source-list').append(row);
  });
  const empty = document.createElement('span');
  $('routing-matrix').append(empty);
  ['WORM', 'FLY ♀', 'FLY ♂', 'HUMAN', 'NULL'].forEach((label) => {
    const cell = document.createElement('span');
    cell.className = 'route-col'; cell.textContent = label;
    $('routing-matrix').append(cell);
  });
  SOURCE_LABELS.forEach((label, row) => {
    const name = document.createElement('span');
    name.className = 'route-label'; name.textContent = label;
    $('routing-matrix').append(name);
    for (let col = 0; col < 5; col += 1) {
      const cell = document.createElement('div');
      cell.id = `route-${row}-${col}`; cell.className = 'route-cell'; cell.textContent = '—';
      $('routing-matrix').append(cell);
    }
  });
}

function renderSession() {
  const world = session.world;
  const telemetry = session.telemetry || {};
  $('world-size').textContent = `${world.size} × ${world.size}`;
  $('agent-position').textContent = `${world.agent.x}, ${world.agent.z}`;
  $('scene-goal').textContent = `${world.goal.color ? `${world.goal.color[0].toUpperCase()}${world.goal.color.slice(1)} target` : 'Custom target'} · ${world.goal.x}, ${world.goal.z}`;
  $('scene-goal').style.color = BEACON_COLORS[world.goal.color] || '#b5c9d7';
  $('learning-label').textContent = session.learning ? 'ON' : 'OFF';
  $('metric-steps').textContent = formatNumber(session.steps);
  $('metric-updates').textContent = formatNumber(session.updates);
  $('metric-update-note').textContent = session.learning
    ? `Evolving · model ${(session.model_hash || '').slice(0, 8) || 'live'}`
    : 'Learning paused';
  $('metric-goals').textContent = formatNumber(session.goals_reached);
  $('metric-episode').textContent = `Episode ${formatNumber(session.episodes)}`;
  $('metric-accuracy').textContent = Number.isFinite(session.policy_accuracy) ? `${formatNumber(session.policy_accuracy * 100, 1)}%` : '—';
  $('metric-reward').textContent = formatNumber(world.total_reward, 2);
  const action = Number.isInteger(session.last_action) ? DIRECTION_NAMES[session.last_action] : '—';
  $('metric-action').textContent = `${action} · ${session.last_action_source || 'awaiting action'}`;
  $('metric-action').title = `Last action: ${action}. Selection source: ${session.last_action_source || 'none'}. Teacher probability: ${formatNumber(finite(session.teacher_probability) * 100, 0)}%.`;
  ['blue', 'amber', 'rose'].forEach((color) => {
    $(`goal-${color}`).classList.toggle('active', world.goal.color === color);
    $(`goal-${color}`).setAttribute('aria-pressed', String(world.goal.color === color));
  });
  SOURCE_KEYS.forEach((key, index) => {
    const source = session.sources?.[key];
    const badge = $(`source-${key}-badge`);
    badge.textContent = source ? source.degree_rewired_control ? 'control' : source.status || 'unknown' : 'missing';
    badge.classList.toggle('imported', Boolean(source?.authentic_ready));
    $(`source-${key}-detail`).textContent = source ? `${formatNumber(source.node_count)} ${source.scale === 'brain_region' ? 'regions' : 'nodes'} · ${formatNumber(source.edge_count)} observations` : 'No graph in bundle';
    const topNodes = telemetry.top_nodes?.[key];
    const gate = telemetry.graft_gates?.[index];
    const gateStr = Number.isFinite(gate) ? `Gate ${(gate * 100).toFixed(0)}%` : '';
    const nodeStr = Array.isArray(topNodes) && topNodes.length
      ? `Top: ${topNodes.slice(0, 3).map((n) => `${n.id}(${finite(n.activity).toFixed(2)})`).join(' ')}`
      : '';
    $(`source-${key}-nodes`).textContent = [gateStr, nodeStr].filter(Boolean).join(' · ') || 'Top firing: —';
    const activity = finite(session.activity?.[index]);
    $(`source-${key}-activity`).textContent = activity.toFixed(3);
    $(`source-${key}-bar`).style.width = `${clip(activity / (1 + Math.abs(activity)), 0, 1) * 100}%`;
  });
  if ($('telemetry-delta')) {
    $('telemetry-delta').textContent = Number.isFinite(telemetry.weight_delta_norm) ? telemetry.weight_delta_norm.toFixed(3) : '—';
    $('telemetry-graft').textContent = Number.isFinite(telemetry.graft_impact) ? telemetry.graft_impact.toFixed(3) : '—';
    $('telemetry-entropy').textContent = Number.isFinite(telemetry.route_entropy) ? `${(telemetry.route_entropy * 100).toFixed(0)}%` : '—';
    const probs = Array.isArray(telemetry.action_probs) ? telemetry.action_probs : [0.25, 0.25, 0.25, 0.25];
    for (let dir = 0; dir < 4; dir += 1) {
      const p = clip(finite(probs[dir], 0.25), 0, 1);
      if ($(`prob-${dir}`)) $(`prob-${dir}`).textContent = `${(p * 100).toFixed(0)}%`;
      if ($(`prob-bar-${dir}`)) $(`prob-bar-${dir}`).style.width = `${p * 100}%`;
      if ($(`prob-cell-${dir}`)) $(`prob-cell-${dir}`).classList.toggle('teacher', telemetry.expert_action === dir);
    }
  }
  const env = telemetry.environment || {};
  const activePreset = env.preset || 'labyrinth';
  if ($('world-preset-badge')) $('world-preset-badge').textContent = activePreset;
  if ($('env-hud-summary') && Number.isFinite(env.geodesic_distance)) {
    $('env-hud-summary').textContent = `Geo ${env.geodesic_distance} · Detour ${finite(env.detour_index, 1).toFixed(2)}× · Choke ${(env.choke_points || []).length}`;
  }
  document.querySelectorAll('.world-size-btn').forEach((btn) => {
    btn.classList.toggle('active', Number(btn.dataset.worldSize) === world.size);
  });
  document.querySelectorAll('.world-preset-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.worldPreset === activePreset);
  });
  const nm = telemetry.neuromodulators || {};
  if ($('mod-regime') && nm.regime) {
    $('mod-regime').textContent = nm.regime;
    $('mod-gain').textContent = `Gain ${finite(nm.plasticity_gain, 1).toFixed(2)}×`;
    const da = clip(finite(nm.dopamine, 0.5), 0, 1);
    const ht = clip(finite(nm.serotonin, 0.5), 0, 1);
    const oa = clip(finite(nm.octopamine, 0.5), 0, 1);
    $('mod-da').textContent = da.toFixed(2);
    $('mod-bar-da').style.width = `${da * 100}%`;
    $('mod-5ht').textContent = ht.toFixed(2);
    $('mod-bar-5ht').style.width = `${ht * 100}%`;
    $('mod-oa').textContent = oa.toFixed(2);
    $('mod-bar-oa').style.width = `${oa * 100}%`;
  }
  if ($('env-complexity-foot') && Number.isFinite(env.free_cells)) {
    $('env-complexity-foot').textContent = `Free ${env.free_cells}/${env.interior_cells} (${(finite(env.obstacle_density) * 100).toFixed(0)}% walls) · Corridors ${env.corridor_cells} · Junctions ${env.branch_junctions} · Plume ${(finite(env.chemoattractant) * 100).toFixed(0)}%`;
  }
  SOURCE_KEYS.forEach((key, idx) => {
    const ablEl = $(`ablation-${key}`);
    const tauEl = $(`tau-${key}`);
    if (ablEl) {
      const val = telemetry.source_ablation?.[key];
      ablEl.textContent = Number.isFinite(val) ? `Δ ${val.toFixed(3)}` : '—';
    }
    if (tauEl) {
      const tau = telemetry.liquid_tau?.[idx];
      const hubs = telemetry.connectome_motifs?.[key]?.rich_club_hubs || [];
      const hubStr = hubs.slice(0, 2).map((h) => `${h.id}(d=${h.degree})`).join(' ');
      tauEl.textContent = `τ=${Number.isFinite(tau) ? tau.toFixed(2) : '—'}s · ${hubStr || '—'}`;
    }
  });
  for (let row = 0; row < 4; row += 1) for (let col = 0; col < 5; col += 1) {
    const value = clip(finite(session.routes?.[row]?.[col]), 0, 1);
    const cell = $(`route-${row}-${col}`);
    cell.textContent = value.toFixed(2);
    cell.title = `${SOURCE_LABELS[row]} receives from ${col === 4 ? 'null route' : SOURCE_LABELS[col]}: ${value.toFixed(4)}`;
    cell.style.background = `rgba(71, 182, 161, ${0.06 + value * 0.54})`;
    cell.style.borderColor = `rgba(94, 233, 206, ${0.08 + value * 0.36})`;
    cell.style.color = value > 0.35 ? '#c3fff0' : '#8ca8b6';
  }
  renderCognitiveTelemetry(telemetry);
  renderConsolidationAndDalesTelemetry(telemetry);
  renderSTPAndSpectralTelemetry(telemetry);
  renderBioelectricAndAgencyTelemetry(telemetry);
  renderEcologicalTelemetry(telemetry);
  renderLoss(); renderChat(); renderFacts(); renderPersistence();
  renderEvaluation(); renderNavigation();
  $('service-error').hidden = !session.runtime?.last_error;
  $('service-error-message').textContent = session.runtime?.last_error ? `Live service paused after an error: ${session.runtime.last_error}. Review the session before resuming.` : '';
  $('evidence-scope').textContent = session.evidence_scope || 'Experimental synthetic navigation. Online supervised adaptation; policy match is recent teacher agreement.';
  $('graph-id').textContent = [
    session.graph_hash ? `GRAPH ${session.graph_hash.slice(0, 8)}` : '',
    session.model_hash ? `MODEL ${session.model_hash.slice(0, 8)}` : '',
  ].filter(Boolean).join(' · ');
  $('graph-id').title = `Graph SHA-256: ${session.graph_hash || ''}\nModel SHA-256: ${session.model_hash || ''}`;
  if (webglReady) updateWorld(world);
}

function initCompassDial() {
  const g = $('compass-wedges');
  if (!g) return;
  g.innerHTML = '';
  const numWedges = 16;
  const cx = 60, cy = 60, r1 = 20, r2 = 50;
  for (let i = 0; i < numWedges; i += 1) {
    const angle = (2 * Math.PI * i) / numWedges - Math.PI / 2;
    const half = (Math.PI / numWedges);
    const a1 = angle - half, a2 = angle + half;
    const x1 = cx + r1 * Math.cos(a1), y1 = cy + r1 * Math.sin(a1);
    const x2 = cx + r2 * Math.cos(a1), y2 = cy + r2 * Math.sin(a1);
    const x3 = cx + r2 * Math.cos(a2), y3 = cy + r2 * Math.sin(a2);
    const x4 = cx + r1 * Math.cos(a2), y4 = cy + r1 * Math.sin(a2);
    const d = `M ${x1.toFixed(2)} ${y1.toFixed(2)} L ${x2.toFixed(2)} ${y2.toFixed(2)} A ${r2} ${r2} 0 0 1 ${x3.toFixed(2)} ${y3.toFixed(2)} L ${x4.toFixed(2)} ${y4.toFixed(2)} A ${r1} ${r1} 0 0 0 ${x1.toFixed(2)} ${y1.toFixed(2)} Z`;
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', d);
    path.setAttribute('id', `compass-wedge-${i}`);
    path.setAttribute('class', 'compass-wedge');
    path.setAttribute('fill', 'var(--cyan)');
    g.appendChild(path);
  }
}

function renderCognitiveTelemetry(telemetry) {
  const cmp = telemetry.compass || {};
  if ($('compass-heading-val') && Number.isFinite(cmp.pva_heading)) {
    $('compass-heading-val').textContent = `${cmp.pva_heading.toFixed(2)} rad`;
    $('compass-coherence-val').textContent = finite(cmp.pva_coherence, 0).toFixed(2);
    if ($('compass-bar-coh')) $('compass-bar-coh').style.width = `${clip(finite(cmp.pva_coherence), 0, 1) * 100}%`;
    const needle = $('compass-pva-needle');
    if (needle) {
      const deg = (cmp.pva_heading * 180) / Math.PI;
      needle.style.transform = `rotate(${deg}deg)`;
    }
    const statusPill = $('compass-status');
    if (statusPill) {
      statusPill.textContent = cmp.disoriented ? 'Optomotor reflex active' : 'Coherent bump';
      statusPill.classList.toggle('imported', !cmp.disoriented);
    }
    if (Array.isArray(cmp.wedges)) {
      cmp.wedges.forEach((w, i) => {
        const el = $(`compass-wedge-${i}`);
        if (el) el.style.opacity = (0.15 + clip(w * 3.5, 0, 0.85)).toFixed(2);
      });
    }
  }

  const efe = telemetry.active_inference || {};
  if ($('efe-dist-val') && Array.isArray(efe.efe_probs)) {
    const names = ['N', 'E', 'S', 'W'];
    $('efe-dist-val').textContent = names.map((n, i) => `${n}: ${(clip(efe.efe_probs[i], 0, 1) * 100).toFixed(0)}%`).join('  ');
    if ($('efe-breakdown') && Array.isArray(efe.pragmatic)) {
      const b = efe.best_action || 0;
      $('efe-breakdown').textContent = `Best: ${names[b]} · Prag: ${finite(efe.pragmatic[b]).toFixed(1)} · Epist: ${finite(efe.epistemic[b]).toFixed(1)} · Emp: ${finite(efe.empowerment[b]).toFixed(2)}`;
    }
  }

  const pp = telemetry.phase_plane || {};
  if ($('phase-status') && Number.isFinite(pp.lyapunov_energy)) {
    $('phase-status').textContent = `L=${pp.lyapunov_energy.toFixed(3)} · drift=${finite(pp.lyapunov_drift).toFixed(3)} [${pp.stability_regime || 'orbit'}]`;
  }

  const mem = telemetry.memory || {};
  const activeMode = mem.mode || 'intact';
  if ($('memory-mode-pill')) $('memory-mode-pill').textContent = activeMode;
  if ($('memory-stats-foot') && Number.isFinite(mem.mapped_cells)) {
    $('memory-stats-foot').textContent = `Mapped cells: ${mem.mapped_cells} · Spatial familiarity: ${(finite(mem.spatial_familiarity) * 100).toFixed(0)}% · Mode: ${activeMode}`;
  }
  document.querySelectorAll('.lesion-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.memoryMode === activeMode);
  });
}

function renderConsolidationAndDalesTelemetry(telemetry) {
  const cons = telemetry.consolidation || {};
  if ($('anchor-kl-pill') && Number.isFinite(cons.anchor_kl_drift)) {
    $('anchor-kl-pill').textContent = `KL drift: ${cons.anchor_kl_drift.toFixed(3)}`;
  }
  if (Array.isArray(cons.route_probs)) {
    cons.route_probs.forEach((p, i) => {
      const probEl = $(`expert-prob-${i}`);
      const barEl = $(`expert-bar-${i}`);
      if (probEl) probEl.textContent = `${(clip(p, 0, 1) * 100).toFixed(0)}%`;
      if (barEl) barEl.style.width = `${(clip(p, 0, 1) * 100).toFixed(0)}%`;
    });
  }
  if ($('clcs-diagnostics')) {
    const h = finite(cons.router_entropy, 1.38).toFixed(2);
    const bal = finite(cons.router_balance, 1.0).toFixed(2);
    const gate = finite(cons.gate_abs_mean, 0.0).toFixed(3);
    const mem = finite(cons.memory_entropy, 1.39).toFixed(2);
    $('clcs-diagnostics').textContent = `H=${h} · Bal=${bal} · Gate=${gate} · Mem=${mem}`;
  }

  const dl = telemetry.dales_law || {};
  const sources = ['worm', 'fly_f', 'fly_m', 'human'];
  let allContractive = true;
  sources.forEach((src) => {
    const rep = dl[src] || {};
    const daleEl = $(`dale-${src}`);
    const specEl = $(`spectral-${src}`);
    if (daleEl && Number.isFinite(rep.compliance_ratio)) {
      daleEl.textContent = `${(rep.compliance_ratio * 100).toFixed(0)}%`;
    }
    if (specEl && Number.isFinite(rep.spectral_radius_bound)) {
      const stat = rep.is_contractive ? 'contractive' : 'expansive';
      specEl.textContent = `ρ≤${rep.spectral_radius_bound.toFixed(2)} · ${stat}`;
      if (!rep.is_contractive) allContractive = false;
    }
  });
  if ($('dales-contractive-pill')) {
    $('dales-contractive-pill').textContent = allContractive ? 'Contractive ρ≤0.90' : 'Expansive spectral bound';
    $('dales-contractive-pill').classList.toggle('imported', allContractive);
  }
}

function renderSTPAndSpectralTelemetry(telemetry) {
  const stp = telemetry.stp || {};
  const u = finite(stp.mean_release_prob, 0.35);
  const r = finite(stp.mean_vesicle_pool, 1.0);
  const eff = finite(stp.mean_synaptic_efficacy, 1.0);

  if ($('stp-efficacy-pill')) {
    $('stp-efficacy-pill').textContent = `Efficacy: ${eff.toFixed(2)}×`;
  }
  if ($('stp-u-val')) $('stp-u-val').textContent = u.toFixed(2);
  if ($('stp-r-val')) $('stp-r-val').textContent = r.toFixed(2);
  if ($('stp-e-val')) $('stp-e-val').textContent = `${eff.toFixed(2)}×`;

  if ($('stp-u-bar')) $('stp-u-bar').style.width = `${(clip(u, 0, 1) * 100).toFixed(0)}%`;
  if ($('stp-r-bar')) $('stp-r-bar').style.width = `${(clip(r, 0, 1) * 100).toFixed(0)}%`;
  if ($('stp-e-bar')) $('stp-e-bar').style.width = `${(clip(eff / 2.0, 0, 1) * 100).toFixed(0)}%`;

  if ($('stp-filtering-note')) {
    const dep = ((stp.depression_fraction || 0) * 100).toFixed(0);
    const fac = ((stp.facilitation_fraction || 0) * 100).toFixed(0);
    const status = dep > 0 ? 'Short-Term Depression' : fac > 0 ? 'Short-Term Facilitation' : 'Idle Baseline';
    $('stp-filtering-note').textContent = `Depression: ${dep}% · Facilitation: ${fac}% · ${status}`;
  }

  const sd = telemetry.spectral_diffusion || {};
  const wormSd = sd.worm || {};
  const s05 = finite(wormSd.scale_0_5 || wormSd['scale_0.5'], 0.95);
  const s20 = finite(wormSd.scale_2_0 || wormSd['scale_2.0'], 0.65);
  const s60 = finite(wormSd.scale_6_0 || wormSd['scale_6.0'], 0.30);

  if ($('spectral-local-val')) $('spectral-local-val').textContent = s05.toFixed(2);
  if ($('spectral-meso-val')) $('spectral-meso-val').textContent = s20.toFixed(2);
  if ($('spectral-macro-val')) $('spectral-macro-val').textContent = s60.toFixed(2);

  if ($('spectral-local-bar')) $('spectral-local-bar').style.width = `${(clip(s05, 0, 1) * 100).toFixed(0)}%`;
  if ($('spectral-meso-bar')) $('spectral-meso-bar').style.width = `${(clip(s20, 0, 1) * 100).toFixed(0)}%`;
  if ($('spectral-macro-bar')) $('spectral-macro-bar').style.width = `${(clip(s60, 0, 1) * 100).toFixed(0)}%`;

  const bb = telemetry.byte_bridge || {};
  if ($('byte-intent-pill') && bb.semantic_intent) {
    $('byte-intent-pill').textContent = String(bb.semantic_intent);
  }
  if ($('byte-bridge-note')) {
    const ent = finite(bb.byte_entropy, 4.0).toFixed(2);
    const conf = finite(bb.confidence, 0.8).toFixed(2);
    const chars = Array.isArray(bb.top_byte_chars) ? bb.top_byte_chars.map(c => `'${c}'`).join(', ') : 'none';
    $('byte-bridge-note').textContent = `Entropy ${ent} · Conf ${conf} · Attractor: [${chars}]`;
  }
}

function renderBioelectricAndAgencyTelemetry(telemetry) {
  const bio = telemetry.bioelectric || {};
  const vmem = finite(bio.global_mean_mv, -65.0);
  const vrest = finite(bio.resting_baseline_mv, -65.0);
  const gain = finite(bio.excitability_gain, 1.0);
  const depRatio = finite(bio.depolarized_ratio, 0.0);

  if ($('bioelectric-gain-pill')) {
    $('bioelectric-gain-pill').textContent = `Gain: ${gain.toFixed(2)}×`;
    $('bioelectric-gain-pill').classList.toggle('imported', gain > 1.02);
  }
  if ($('bio-vmem-val')) $('bio-vmem-val').textContent = `${vmem.toFixed(1)} mV`;
  if ($('bio-vrest-val')) $('bio-vrest-val').textContent = `${vrest.toFixed(1)} mV`;
  if ($('bio-gain-val')) $('bio-gain-val').textContent = `${gain.toFixed(2)}×`;

  const vRange = (vmem - (-85.0)) / 65.0;
  if ($('bio-vmem-bar')) $('bio-vmem-bar').style.width = `${(clip(vRange, 0, 1) * 100).toFixed(0)}%`;
  const vRestRange = (vrest - (-85.0)) / 65.0;
  if ($('bio-vrest-bar')) $('bio-vrest-bar').style.width = `${(clip(vRestRange, 0, 1) * 100).toFixed(0)}%`;
  if ($('bio-gain-bar')) $('bio-gain-bar').style.width = `${(clip(gain / 2.0, 0, 1) * 100).toFixed(0)}%`;

  if ($('bioelectric-note')) {
    $('bioelectric-note').textContent = `Depolarized: ${(depRatio * 100).toFixed(0)}% · Slow Gap Junction Diffusive Memory Attractor`;
  }

  const sm = telemetry.self_model || {};
  const agency = finite(sm.agency_score, 0.0);
  const predErr = finite(sm.prediction_error, 0.0);

  const arch = telemetry.archaeology || {};
  const mtpr = finite(arch.mtpr, 1.0);

  if ($('agency-regime-pill') && sm.agency_regime) {
    $('agency-regime-pill').textContent = String(sm.agency_regime);
    $('agency-regime-pill').classList.toggle('imported', agency > 0.1);
  }

  if ($('agency-score-val')) $('agency-score-val').textContent = `${agency >= 0 ? '+' : ''}${agency.toFixed(2)}`;
  if ($('self-model-err-val')) $('self-model-err-val').textContent = predErr.toFixed(3);
  if ($('arch-mtpr-val')) $('arch-mtpr-val').textContent = `${(mtpr * 100).toFixed(0)}%`;

  if ($('agency-score-bar')) $('agency-score-bar').style.width = `${(clip((agency + 1.0) / 2.0, 0, 1) * 100).toFixed(0)}%`;
  if ($('self-model-err-bar')) $('self-model-err-bar').style.width = `${(clip(1.0 - predErr, 0, 1) * 100).toFixed(0)}%`;
  if ($('arch-mtpr-bar')) $('arch-mtpr-bar').style.width = `${(clip(mtpr, 0, 1) * 100).toFixed(0)}%`;

  if ($('arch-diagnostics-note')) {
    const tgt = arch.target_species || 'fly_f';
    const lesSim = ((arch.lesioned_fidelity || 1.0) * 100).toFixed(0);
    const rDelta = finite(arch.rescue_delta, 0.0);
    $('arch-diagnostics-note').textContent = `Target: ${tgt} · Lesion Sim: ${lesSim}% · Bioelectric Rescue Δ: ${rDelta >= 0 ? '+' : ''}${rDelta.toFixed(3)} [${arch.regime || 'preserved'}]`;
  }
}

function renderEcologicalTelemetry(telemetry) {
  const env = telemetry.environment || {};
  const sub = env.substrate || {};
  const circadian = env.circadian || {};
  const sensilla = env.antennal_tropotaxis || {};
  const eye = env.compound_eye || {};
  const gates = env.dynamic_gates || {};

  if ($('substrate-type-pill')) {
    const stype = String(sub.type || 'standard').replace('_', ' ');
    $('substrate-type-pill').textContent = stype;
    $('substrate-type-pill').classList.toggle('imported', sub.type && sub.type !== 'standard');
  }

  const drag = finite(sub.drag_factor, 1.0);
  const temp = finite(sub.temperature_celsius, 22.0);
  const lux = finite(circadian.ambient_lux, 1.0);

  if ($('sub-drag-val')) $('sub-drag-val').textContent = `${drag.toFixed(2)}×`;
  if ($('sub-temp-val')) $('sub-temp-val').textContent = `${temp.toFixed(1)}°C`;
  if ($('circadian-lux-val')) $('circadian-lux-val').textContent = `${lux.toFixed(2)} (${circadian.diurnal_state || 'day'})`;

  if ($('sub-drag-bar')) $('sub-drag-bar').style.width = `${(clip(drag / 2.0, 0, 1) * 100).toFixed(0)}%`;
  if ($('sub-temp-bar')) $('sub-temp-bar').style.width = `${(clip((temp - 18.0) / 12.0, 0, 1) * 100).toFixed(0)}%`;
  if ($('circadian-lux-bar')) $('circadian-lux-bar').style.width = `${(clip(lux, 0, 1) * 100).toFixed(0)}%`;

  if ($('substrate-breakdown-note')) {
    const counts = env.substrates?.counts || {};
    $('substrate-breakdown-note').textContent = `Agar: ${counts.viscous_agar || 0} · Bioelectric: ${counts.bioelectric || 0} · Thermal: ${counts.thermal_comfort || 0} · Standard: ${counts.standard || 0}`;
  }

  const sL = finite(sensilla.left_sensilla, 0.5);
  const sR = finite(sensilla.right_sensilla, 0.5);
  const contrast = finite(sensilla.bilateral_contrast, 0.0);
  const steer = String(sensilla.tropotaxis_steer || 'CENTER').toUpperCase();

  if ($('sensilla-left-val')) $('sensilla-left-val').textContent = sL.toFixed(3);
  if ($('sensilla-right-val')) $('sensilla-right-val').textContent = sR.toFixed(3);
  if ($('tropotaxis-steer-val')) $('tropotaxis-steer-val').textContent = `${steer} (${contrast >= 0 ? '+' : ''}${contrast.toFixed(2)})`;

  if ($('sensilla-left-bar')) $('sensilla-left-bar').style.width = `${(clip(sL, 0, 1) * 100).toFixed(0)}%`;
  if ($('sensilla-right-bar')) $('sensilla-right-bar').style.width = `${(clip(sR, 0, 1) * 100).toFixed(0)}%`;
  if ($('tropotaxis-steer-bar')) $('tropotaxis-steer-bar').style.width = `${(clip((contrast + 1.0) / 2.0, 0, 1) * 100).toFixed(0)}%`;

  if ($('looming-status-pill')) {
    const looming = Boolean(eye.looming_alert);
    $('looming-status-pill').textContent = looming ? '⚠️ Looming alert' : 'Clear trajectory';
    $('looming-status-pill').classList.toggle('imported', !looming);
    $('looming-status-pill').classList.toggle('evaluation-warning', looming);
  }

  if ($('optic-gates-note')) {
    const ttc = finite(eye.looming_tau_ttc, 10.0);
    const expRate = finite(eye.retinal_expansion_rate, 0.1);
    const gCount = gates.count || 0;
    const gOpen = gates.primary_gate_open ? 'OPEN' : 'RESTRICTED';
    $('optic-gates-note').textContent = `τ_TTC: ${ttc.toFixed(1)} ticks · Expansion: ${expRate.toFixed(2)}/s · Choke Portals: ${gCount} (${gOpen})`;
  }
}

function renderLoss() {
  const history = (session.loss_history || []).filter(Number.isFinite).slice(-64);
  $('loss-value').textContent = Number.isFinite(session.last_loss) ? session.last_loss.toFixed(4) : '—';
  $('loss-note').textContent = history.length ? `${history.length} recent updates · supervised action prediction` : 'Loss appears after the first learning update.';
  if (!history.length) { $('loss-line').setAttribute('d', ''); $('loss-area').setAttribute('d', ''); return; }
  const lo = Math.min(...history), hi = Math.max(...history), range = Math.max(hi - lo, 0.01);
  const points = history.map((value, index) => [history.length === 1 ? 280 : index / (history.length - 1) * 556 + 2, 74 - (value - lo) / range * 62]);
  const path = points.map(([x, y], index) => `${index ? 'L' : 'M'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  $('loss-line').setAttribute('d', history.length === 1 ? `${path} l1,0` : path);
  $('loss-area').setAttribute('d', `${path} L${points.at(-1)[0]},88 L${points[0][0]},88 Z`);
}

function renderChat() {
  const messages = Array.isArray(session.chat) ? session.chat : [];
  const signature = JSON.stringify(messages);
  if (signature === lastChat) return;
  lastChat = signature;
  if (!messages.length) return;
  const container = $('chat-messages');
  const keepAtBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 70;
  container.replaceChildren();
  for (const message of messages) {
    const entry = document.createElement('div');
    entry.className = `chat-message ${message.role === 'user' ? 'user' : 'assistant'}`;
    const role = document.createElement('div'); role.className = 'message-role'; role.textContent = message.role === 'user' ? 'You' : 'Neurograft · local';
    const content = document.createElement('div'); content.className = 'message-content'; content.textContent = String(message.content ?? '');
    entry.append(role, content); container.append(entry);
  }
  if (keepAtBottom || document.activeElement === $('chat-input')) container.scrollTop = container.scrollHeight;
}

function renderFacts() {
  const facts = session.facts || {};
  const signature = JSON.stringify(facts);
  if (signature === lastFacts) return;
  lastFacts = signature;
  const entries = Object.entries(facts);
  $('fact-count').textContent = entries.length;
  $('facts-list').replaceChildren();
  if (!entries.length) {
    const empty = document.createElement('p'); empty.className = 'empty-note'; empty.textContent = 'No facts yet. Use “remember key = value” in chat.'; $('facts-list').append(empty);
  }
  entries.forEach(([key, value]) => {
    const row = document.createElement('div'); row.className = 'fact-row';
    const label = document.createElement('span'); label.className = 'fact-key'; label.textContent = key;
    const detail = document.createElement('span'); detail.className = 'fact-value'; detail.textContent = String(value);
    row.append(label, detail); $('facts-list').append(row);
  });
}

function readableDate(value) {
  if (!value) return '';
  const date = new Date(typeof value === 'number' && value < 1e12 ? value * 1000 : value);
  return Number.isFinite(date.getTime()) ? date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '';
}

function renderPersistence() {
  const runtime = session.runtime || {};
  const legacyAuxiliaryReset = runtime.checkpoint_compatibility?.auxiliary_state_restored === false;
  $('checkpoint-compatibility-note').hidden = !legacyAuxiliaryReset;
  $('checkpoint-compatibility-note').textContent = legacyAuxiliaryReset ? 'Legacy checkpoint restored: policy retained; auxiliary diagnostic state was initialized afresh.' : '';
  const autosave = finite(runtime.autosave_seconds);
  $('autosave-status').textContent = runtime.autosave_seconds === undefined ? 'Autosave status pending' : autosave > 0 ? `Autosave every ${formatNumber(autosave)} seconds` : 'Autosave disabled';
  if (runtime.last_error) {
    $('autosave-status').textContent = `Service notice: ${String(runtime.last_error)}`;
    $('autosave-status').title = String(runtime.last_error);
  } else $('autosave-status').title = '';
  const saved = session.last_saved;
  if (saved) {
    const path = typeof saved === 'string' ? saved : saved.path || saved.name || 'session';
    const name = String(path).split(/[\\/]/).at(-1);
    const time = typeof saved === 'object' ? readableDate(saved.time || saved.timestamp || saved.saved_at) : '';
    $('saved-status').textContent = `Last saved ${time ? `at ${time}` : ''} · ${name}`;
  } else $('saved-status').textContent = 'No save receipt yet.';
  const checkpoints = Array.isArray(session.checkpoints) ? session.checkpoints : [];
  const signature = JSON.stringify(checkpoints);
  if (signature === lastCheckpoints) return;
  lastCheckpoints = signature;
  $('checkpoint-count').textContent = checkpoints.length;
  $('checkpoint-options').replaceChildren();
  $('checkpoint-list').replaceChildren();
  if (!checkpoints.length) {
    const empty = document.createElement('span'); empty.className = 'empty-note'; empty.textContent = 'No checkpoints found.'; $('checkpoint-list').append(empty);
  }
  checkpoints.forEach((checkpoint) => {
    const option = document.createElement('option'); option.value = checkpoint.name; $('checkpoint-options').append(option);
    const item = document.createElement('button'); item.type = 'button'; item.className = 'checkpoint-item';
    const name = document.createElement('span'); name.textContent = checkpoint.name;
    const meta = document.createElement('small'); meta.textContent = `${formatNumber(finite(checkpoint.bytes) / 1024, 1)} KiB${checkpoint.modified ? ` · ${readableDate(checkpoint.modified)}` : ''}`;
    item.append(name, meta); item.addEventListener('click', () => { $('save-name').value = checkpoint.name; $('save-name').focus(); });
    $('checkpoint-list').append(item);
  });
}

function validCheckpointName() {
  const name = $('save-name').value.trim();
  if (!/^[A-Za-z0-9_-]{1,40}$/.test(name)) { showError('Choose a checkpoint name with 1–40 letters, numbers, underscores or hyphens.'); $('save-name').focus(); return null; }
  return name;
}

function renderNavigation() {
  if (!session) return;
  const nav = session.navigation || { mode: 'policy' };
  const map = nav.map || {};
  const size = map.size || session.world.size;
  const probability = nav.teacher_probability ?? session.teacher_probability;
  const label = { policy: 'Raw policy', masked_policy: 'Legal-action mask', observed_map: 'Observed-map planner' }[nav.mode] || nav.mode;
  $('navigation-status').textContent = `${label} · teacher actions ${probability > 0 ? `${Math.round(probability * 100)}% configured` : 'OFF'} · ${(map.reason || 'no map decision yet').replaceAll('_', ' ')}`;
  $('navigation-map-note').textContent = `${map.known_free || 0} observed free cells · ${map.visited || 0} visited · ${map.frontiers || 0} frontier cells. Last executed action source: ${session.last_action_source || 'none'}. Switching modes starts fresh navigation memory.`;
  const svg = $('observed-map'); svg.replaceChildren(); svg.setAttribute('viewBox', `0 0 ${size * 10} ${size * 10}`);
  const add = (tag, attributes) => {
    const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (const [key, value] of Object.entries(attributes)) el.setAttribute(key, value);
    svg.append(el); return el;
  };
  for (const [cells, color] of [[map.blocked_cells || [], '#536273'], [map.free_cells || [], '#164d50'], [map.visited_cells || [], '#3ab49c']]) {
    for (const [x, z] of cells) add('rect', { x: x * 10 + 1, y: z * 10 + 1, width: 8, height: 8, fill: color });
  }
  if (map.path?.length > 1) add('polyline', { points: map.path.map(({ x, z }) => `${x * 10 + 5},${z * 10 + 5}`).join(' '), fill: 'none', stroke: '#c2fff0', 'stroke-width': 1.3 });
  const goal = session.world.goal;
  add('circle', { cx: goal.x * 10 + 5, cy: goal.z * 10 + 5, r: 3, fill: '#ffc36b' });
  const agent = session.world.agent;
  add('circle', { cx: agent.x * 10 + 5, cy: agent.z * 10 + 5, r: 3.5, fill: '#ecffff' });
}

function renderEvaluation() {
  const stale = Boolean(evaluationReport && session && (evaluationReport.model_hash !== session.model_hash || evaluationReport.graph_hash !== session.graph_hash));
  $('evaluate-btn').textContent = evaluationInFlight ? 'Evaluating…' : 'Evaluate frozen policy';
  document.querySelectorAll('[data-evaluation-config]').forEach((field) => { field.disabled = evaluationInFlight; });
  $('evaluation-status').textContent = evaluationInFlight
    ? `Running isolated trials · ${Math.floor((Date.now() - evaluationStarted) / 1000)}s elapsed. Live controls remain available.`
    : evaluationError || (evaluationReport ? `Frozen evaluation complete${stale ? ' · live weights have changed since this snapshot' : ' · matches the currently displayed weight hash'}.` : 'No frozen evaluation yet.');
  $('evaluation-status').classList.toggle('evaluation-warning', Boolean(evaluationError || stale));
  $('evaluation-results').hidden = !evaluationReport;
  if (!evaluationReport) return;
  const report = evaluationReport;
  const config = report.config || {};
  $('evaluation-snapshot').textContent = `Evaluated model ${(report.model_hash || '').slice(0, 12)} · step ${formatNumber(report.checkpoint_steps)} · ${config.size}×${config.size} ${config.preset} · seeds ${(config.seeds || []).join(', ')} · ${config.max_steps} steps/trial`;
  $('evaluation-snapshot').title = `Model SHA-256: ${report.model_hash}\nGraph SHA-256: ${report.graph_hash}\nProtocol: ${report.protocol_id}`;
  if (renderedEvaluation === report) return;
  renderedEvaluation = report;
  const names = { policy: 'Raw policy', no_graft: 'Without grafts', no_recurrence: 'Without recurrence', random: 'Random actions', shortest_path: 'Shortest-path oracle', masked_policy: 'Policy + legal mask', observed_map: 'Observed map + policy', map_without_policy: 'Observed map only' };
  const body = $('evaluation-table-body');
  body.replaceChildren();
  const percent = (value) => Number.isFinite(value) ? `${formatNumber(value * 100, 1)}%` : '—';
  for (const key of ['policy', 'masked_policy', 'observed_map', 'map_without_policy', 'no_graft', 'no_recurrence', 'random', 'shortest_path']) {
    const summary = report.variants?.[key]?.summary;
    if (!summary) continue;
    const row = document.createElement('tr');
    const label = document.createElement('th'); label.scope = 'row'; label.textContent = names[key]; row.append(label);
    const values = [formatNumber(summary.episodes), percent(summary.success_rate), formatNumber(summary.spl, 3), percent(summary.collision_rate), formatNumber(summary.mean_steps, 1), percent(summary.teacher_agreement), percent(summary.proposed_wall_rate), percent(summary.policy_override_rate)];
    for (const value of values) { const cell = document.createElement('td'); cell.textContent = value; row.append(cell); }
    body.append(row);
  }
  const effects = Object.entries(report.paired_effects || {}).map(([key, effect]) => {
    const delta = finite(effect.success_rate_delta) * 100;
    const splDelta = finite(effect.spl_delta);
    return `vs ${names[key] || key}: success ${delta >= 0 ? '+' : ''}${formatNumber(delta, 1)} pp, SPL ${splDelta >= 0 ? '+' : ''}${formatNumber(splDelta, 3)}`;
  });
  $('evaluation-effects').textContent = effects.length ? `Full policy paired differences · ${effects.join(' · ')}` : '';
  $('evaluation-scope').textContent = report.evidence_scope || 'Synthetic navigation trials. Small seed sets are exploratory.';
}

async function evaluatePolicy(event) {
  event.preventDefault();
  if (evaluationInFlight || !session || networkError || isStale()) return;
  const seedText = $('evaluation-seeds').value.split(',').map((value) => value.trim());
  if (seedText.length < 1 || seedText.length > 16 || seedText.some((value) => !/^\d+$/.test(value) || !Number.isSafeInteger(Number(value))) || new Set(seedText.map(Number)).size !== seedText.length) {
    showError('Enter 1–16 distinct, comma-separated nonnegative integers up to 9007199254740991.'); return;
  }
  const payload = { seeds: seedText.map(Number), size: Number($('evaluation-size').value), preset: $('evaluation-preset').value, max_steps: Number($('evaluation-steps').value), include_controllers: $('evaluation-controllers').checked };
  evaluationInFlight = true; evaluationStarted = Date.now(); evaluationError = '';
  updateControls(); renderEvaluation();
  try {
    evaluationReport = await fetchJSON('/api/evaluate', payload, 300000);
    showToast('Frozen navigation trials complete. Export JSON to keep the full receipt.');
  } catch (error) {
    evaluationError = `Evaluation request failed: ${error.message}`;
    showError(evaluationError);
  } finally {
    evaluationInFlight = false; updateControls(); renderEvaluation();
  }
}

async function loadEvaluation() {
  try { evaluationReport = await fetchJSON('/api/evaluation'); renderEvaluation(); updateControls(); }
  catch { /* A transient startup failure is retried when a trial is requested. */ }
}

function exportEvaluation() {
  if (!evaluationReport) return;
  const blob = new Blob([`${JSON.stringify(evaluationReport, null, 2)}\n`], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = url;
  link.download = `neurograft-navigation-${evaluationReport.protocol_id?.slice(0, 12) || 'evaluation'}.json`;
  link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function sendChat(event) {
  event?.preventDefault();
  const message = $('chat-input').value.trim();
  if (!message || writeInFlight || !session || networkError || isStale()) return;
  const result = await mutate('/api/chat', { message });
  if (result) { $('chat-input').value = ''; updateControls(); $('chat-messages').scrollTop = $('chat-messages').scrollHeight; $('chat-input').focus(); }
}

function bindControls() {
  $('evaluation-form').addEventListener('submit', evaluatePolicy);
  $('export-evaluation-btn').addEventListener('click', exportEvaluation);
  $('pause-btn').addEventListener('click', () => control({ action: 'pause' }));
  $('resume-btn').addEventListener('click', () => control({ action: 'resume' }));
  $('step-btn').addEventListener('click', () => control({ action: 'step', steps: 1 }));
  if ($('boost-btn')) $('boost-btn').addEventListener('click', async () => {
    const res = await control({ action: 'boost', steps: 16 });
    if (res) showToast(`Executed 16-step evolution burst (step ${res.steps}, ${res.updates} updates).`);
  });
  $('learning-toggle').addEventListener('change', (event) => control({ action: 'learning', enabled: event.target.checked }));
  $('navigation-mode').addEventListener('change', (event) => control({ action: 'navigation', mode: event.target.value }));
  ['blue', 'amber', 'rose'].forEach((color) => $(`goal-${color}`).addEventListener('click', () => control({ action: 'goal', color })));
  document.querySelectorAll('.world-size-btn').forEach((btn) => btn.addEventListener('click', async () => {
    const size = Number(btn.dataset.worldSize);
    const preset = session?.telemetry?.environment?.preset || 'labyrinth';
    const res = await control({ action: 'world', size, preset });
    if (res) showToast(`Scaled 3D arena to ${size}×${size} (${preset} topology).`);
  }));
  document.querySelectorAll('.world-preset-btn').forEach((btn) => btn.addEventListener('click', async () => {
    const preset = btn.dataset.worldPreset;
    const size = session?.world?.size || 15;
    const res = await control({ action: 'world', size, preset });
    if (res) showToast(`Switched ${size}×${size} arena to ${preset} topology.`);
  }));
  document.querySelectorAll('[data-memory-mode]').forEach((btn) => btn.addEventListener('click', async () => {
    const mode = btn.dataset.memoryMode;
    const res = await control({ action: 'memory_lesion', mode });
    if (res) showToast(`Switched memory assay to ${mode}.`);
  }));
  $('dismiss-error').addEventListener('click', () => { $('error-banner').hidden = true; });
  $('chat-form').addEventListener('submit', sendChat);
  $('chat-input').addEventListener('input', updateControls);
  $('chat-input').addEventListener('keydown', (event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendChat(); } });
  document.querySelectorAll('[data-example]').forEach((button) => button.addEventListener('click', () => { $('chat-input').value = button.dataset.example; updateControls(); $('chat-input').focus(); }));
  $('save-btn').addEventListener('click', async () => {
    const name = validCheckpointName(); if (!name) return;
    const result = await mutate('/api/save', { name });
    if (result) showToast(`Checkpoint “${result.saved?.name || name}” saved.`);
  });
  $('load-btn').addEventListener('click', async () => {
    const name = validCheckpointName(); if (!name) return;
    const result = await mutate('/api/load', { name });
    if (result) showToast(`Restored checkpoint “${name}”.`);
  });
  $('camera-reset').addEventListener('click', resetCamera);
  $('fullscreen-btn').addEventListener('click', toggleFullscreen);
  document.addEventListener('keydown', (event) => {
    if (event.target.closest('input:not([type="checkbox"]), textarea, select, [contenteditable="true"]') || event.ctrlKey || event.metaKey || event.altKey) return;
    if (event.key.toLowerCase() === 'f') { event.preventDefault(); toggleFullscreen(); return; }
    const keyActions = { ArrowUp: 0, w: 0, W: 0, ArrowRight: 1, d: 1, D: 1, ArrowDown: 2, s: 2, S: 2, ArrowLeft: 3, a: 3, A: 3 };
    const direction = keyActions[event.key];
    if (direction === undefined || !session) return;
    event.preventDefault();
    if (writeInFlight || networkError || isStale()) return;
    if (session.running) { if (!event.repeat) showToast('Pause the session to move with the arrow keys or WASD.'); return; }
    control({ action: 'move', direction });
  });
  document.addEventListener('fullscreenchange', resizeScene);
}

async function toggleFullscreen() {
  try { if (document.fullscreenElement) await document.exitFullscreen(); else await $('scene-wrap').requestFullscreen(); }
  catch { showError('Fullscreen is unavailable in this browser window.'); }
}

function resetCamera() {
  orbit.theta = 0.67; orbit.phi = 0.72; orbit.radius = worldSize * 1.65; orbit.targetX = 0; orbit.targetZ = 0;
  updateCamera();
}

function updateCamera() {
  if (!camera) return;
  camera.position.set(orbit.targetX + orbit.radius * Math.sin(orbit.phi) * Math.sin(orbit.theta), orbit.radius * Math.cos(orbit.phi), orbit.targetZ + orbit.radius * Math.sin(orbit.phi) * Math.cos(orbit.theta));
  camera.lookAt(orbit.targetX, 0, orbit.targetZ);
  sceneDirty = true;
}

function resizeScene() {
  if (!renderer || !camera) return;
  const rect = $('scene-wrap').getBoundingClientRect();
  if (!rect.width || !rect.height) return;
  renderer.setSize(rect.width, rect.height, false);
  camera.aspect = rect.width / rect.height;
  camera.updateProjectionMatrix();
  updateCamera();
}

function disposeGroup(group) {
  while (group.children.length) {
    const child = group.children[0];
    child.traverse((object) => {
      object.geometry?.dispose();
      if (Array.isArray(object.material)) object.material.forEach((material) => material.dispose());
      else object.material?.dispose();
    });
    group.remove(child);
  }
}

let pathLine = null;
let haloGroup = null;
let chokeGroup = null;
let lidarGroup = null;
let substrateGroup = null;
let plumeGroup = null;
let leftAntennaTip = null;
let rightAntennaTip = null;
let hemiLight = null;
let keyLight = null;
const haloNodes = [];
const haloBridges = [];

function buildWorld(world) {
  disposeGroup(worldGroup);
  beaconPickables.length = 0;
  haloNodes.length = 0;
  haloBridges.length = 0;
  worldSize = world.size;
  if (scene?.fog) {
    scene.fog.near = Math.max(22, worldSize * 1.4);
    scene.fog.far = Math.max(58, worldSize * 3.8);
  }
  if (camera) {
    camera.far = Math.max(120, worldSize * 5.0);
    camera.updateProjectionMatrix();
  }
  const offset = (worldSize - 1) / 2;
  const material = (color, options = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.6, metalness: 0.25, ...options });
  const floor = new THREE.Mesh(new THREE.BoxGeometry(worldSize + 0.25, 0.28, worldSize + 0.25), material('#152b3b'));
  floor.position.y = -0.2; floor.receiveShadow = true; worldGroup.add(floor);
  floorMesh = new THREE.Mesh(new THREE.PlaneGeometry(worldSize, worldSize), material('#1b3545', { roughness: 0.88, metalness: 0.08 }));
  floorMesh.rotation.x = -Math.PI / 2; floorMesh.position.y = -0.048; floorMesh.receiveShadow = true; worldGroup.add(floorMesh);
  const grid = new THREE.GridHelper(worldSize, worldSize, '#365969', '#2c4a5d');
  grid.position.y = -0.04; grid.material.transparent = true; grid.material.opacity = 0.65; worldGroup.add(grid);
  const edge = new THREE.EdgesGeometry(floor.geometry);
  const outline = new THREE.LineSegments(edge, new THREE.LineBasicMaterial({ color: '#457281', transparent: true, opacity: 0.5 }));
  outline.position.copy(floor.position); worldGroup.add(outline);
  wallGroup = new THREE.Group(); worldGroup.add(wallGroup);
  for (const obstacle of world.obstacles || []) {
    const isBorder = obstacle.x === 0 || obstacle.z === 0 || obstacle.x === worldSize - 1 || obstacle.z === worldSize - 1;
    const h = isBorder ? 0.58 : 0.78;
    const wallColor = isBorder ? '#22384a' : '#2e4d66';
    const wall = new THREE.Mesh(new THREE.BoxGeometry(0.94, h, 0.94), material(wallColor, { roughness: 0.45, metalness: 0.32 }));
    wall.position.set(obstacle.x - offset, h / 2 - 0.05, obstacle.z - offset); wall.castShadow = true; wall.receiveShadow = true; wallGroup.add(wall);
    const cap = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(0.94, h, 0.94)), new THREE.LineBasicMaterial({ color: isBorder ? '#456478' : '#6393b0', transparent: true, opacity: 0.56 }));
    cap.position.copy(wall.position); wallGroup.add(cap);
  }
  beaconGroup = new THREE.Group(); worldGroup.add(beaconGroup);
  for (const beacon of world.beacons || []) {
    const color = BEACON_COLORS[beacon.color] || '#9fb6c9';
    const group = new THREE.Group(); group.position.set(beacon.x - offset, 0, beacon.z - offset); group.userData.beacon = beacon;
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.31, 0.1, 24), material(color, { emissive: color, emissiveIntensity: 0.12 }));
    base.position.y = 0.03; group.add(base);
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.5, 12), material(color, { emissive: color, emissiveIntensity: 0.3 }));
    post.position.y = 0.3; group.add(post);
    const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(0.21), material(color, { emissive: color, emissiveIntensity: 0.55, metalness: 0.2, roughness: 0.25 }));
    crystal.position.y = 0.65; group.add(crystal);
    const ring = new THREE.Mesh(new THREE.RingGeometry(0.32, 0.36, 40), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.6, side: THREE.DoubleSide }));
    ring.rotation.x = -Math.PI / 2; ring.position.y = 0.015; group.add(ring);
    const plume = new THREE.Mesh(new THREE.RingGeometry(0.55, 0.95, 40), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.12, side: THREE.DoubleSide }));
    plume.rotation.x = -Math.PI / 2; plume.position.y = 0.01; group.add(plume);
    group.traverse((object) => { if (object.isMesh) { object.userData.beacon = beacon; beaconPickables.push(object); } });
    beaconGroup.add(group);
  }
  agentGroup = new THREE.Group(); worldGroup.add(agentGroup);
  const agentBody = new THREE.Mesh(new THREE.SphereGeometry(0.23, 24, 16), material('#6af4d2', { emissive: '#3ce4ba', emissiveIntensity: 0.35, metalness: 0.4, roughness: 0.25 }));
  agentBody.position.y = 0.25; agentBody.scale.y = 0.8; agentBody.castShadow = true; agentGroup.add(agentBody);
  const agentHalo = new THREE.Mesh(new THREE.RingGeometry(0.29, 0.33, 36), new THREE.MeshBasicMaterial({ color: '#5ee9ce', transparent: true, opacity: 0.65, side: THREE.DoubleSide }));
  agentHalo.rotation.x = -Math.PI / 2; agentHalo.position.y = 0.02; agentGroup.add(agentHalo);
  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.27, 3), material('#d9fff1', { emissive: '#82f7d0', emissiveIntensity: 0.25 }));
  nose.rotation.x = -Math.PI / 2; nose.position.set(0, 0.24, -0.31); agentGroup.add(nose);
  const antMat = new THREE.LineBasicMaterial({ color: '#5ee9ce', transparent: true, opacity: 0.8 });
  const antLGeom = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0.24, -0.2), new THREE.Vector3(-0.15, 0.32, -0.42)]);
  const antRGeom = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0.24, -0.2), new THREE.Vector3(0.15, 0.32, -0.42)]);
  agentGroup.add(new THREE.Line(antLGeom, antMat));
  agentGroup.add(new THREE.Line(antRGeom, antMat));
  leftAntennaTip = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), material('#5ee9ce', { emissive: '#5ee9ce', emissiveIntensity: 0.6 }));
  leftAntennaTip.position.set(-0.15, 0.32, -0.42);
  agentGroup.add(leftAntennaTip);
  rightAntennaTip = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), material('#5ee9ce', { emissive: '#5ee9ce', emissiveIntensity: 0.6 }));
  rightAntennaTip.position.set(0.15, 0.32, -0.42);
  agentGroup.add(rightAntennaTip);
  goalGroup = new THREE.Group(); worldGroup.add(goalGroup);
  const target = new THREE.Mesh(new THREE.RingGeometry(0.4, 0.44, 56), new THREE.MeshBasicMaterial({ color: '#69b5ff', transparent: true, opacity: 0.9, side: THREE.DoubleSide }));
  target.rotation.x = -Math.PI / 2; target.position.y = 0.025; goalGroup.add(target);
  const outerTarget = new THREE.Mesh(new THREE.RingGeometry(0.48, 0.49, 56), new THREE.MeshBasicMaterial({ color: '#69b5ff', transparent: true, opacity: 0.32, side: THREE.DoubleSide }));
  outerTarget.rotation.x = -Math.PI / 2; outerTarget.position.y = 0.026; goalGroup.add(outerTarget);
  trailLine = new THREE.Line(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: '#5ee9ce', transparent: true, opacity: 0.35 }));
  worldGroup.add(trailLine);
  pathLine = new THREE.Line(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: '#f5be66', transparent: true, opacity: 0.68 }));
  worldGroup.add(pathLine);
  chokeGroup = new THREE.Group(); worldGroup.add(chokeGroup);
  lidarGroup = new THREE.Group(); worldGroup.add(lidarGroup);
  substrateGroup = new THREE.Group(); worldGroup.add(substrateGroup);
  plumeGroup = new THREE.Group(); worldGroup.add(plumeGroup);
  haloGroup = new THREE.Group(); haloGroup.position.y = Math.max(2.4, worldSize * 0.17); worldGroup.add(haloGroup);
  const haloRadius = Math.max(2.15, worldSize * 0.18);
  const positions = SOURCE_COLORS.map((_, idx) => {
    const angle = idx * Math.PI / 2 + Math.PI / 4;
    return new THREE.Vector3(Math.cos(angle) * haloRadius, 0, Math.sin(angle) * haloRadius);
  });
  SOURCE_COLORS.forEach((color, idx) => {
    const sphere = new THREE.Mesh(new THREE.SphereGeometry(0.17, 16, 12), material(color, { emissive: color, emissiveIntensity: 0.58 }));
    sphere.position.copy(positions[idx]);
    haloGroup.add(sphere);
    haloNodes.push(sphere);
  });
  for (let dst = 0; dst < 4; dst += 1) {
    for (let src = 0; src < 4; src += 1) {
      if (src === dst) continue;
      const mid = positions[src].clone().add(positions[dst]).multiplyScalar(0.5);
      mid.y += 0.32;
      const curve = new THREE.QuadraticBezierCurve3(positions[src], mid, positions[dst]);
      const line = new THREE.Line(
        new THREE.BufferGeometry().setFromPoints(curve.getPoints(16)),
        new THREE.LineBasicMaterial({ color: SOURCE_COLORS[src], transparent: true, opacity: 0.15 })
      );
      haloGroup.add(line);
      haloBridges.push({ dst, src, line });
    }
  }
  const shadowGround = new THREE.Mesh(new THREE.PlaneGeometry(140, 140), material('#0b1521', { roughness: 1, metalness: 0 }));
  shadowGround.rotation.x = -Math.PI / 2; shadowGround.position.y = -0.36; shadowGround.receiveShadow = true; worldGroup.add(shadowGround);
  agentGroup.position.set(world.agent.x - offset, 0, world.agent.z - offset);
  agentGroup.rotation.y = -finite(world.agent.direction) * Math.PI / 2;
  resetCamera();
}

function updateWorld(world) {
  const structuralKey = JSON.stringify([world.size, world.obstacles, world.beacons]);
  if (structuralKey !== renderedWorldKey) { renderedWorldKey = structuralKey; buildWorld(world); lastWorldVisualKey = ''; }
  const offset = (world.size - 1) / 2;
  agentTarget.x = world.agent.x - offset;
  agentTarget.z = world.agent.z - offset;
  agentTarget.angle = -finite(world.agent.direction) * Math.PI / 2;
  goalGroup.position.set(world.goal.x - offset, 0, world.goal.z - offset);
  const goalColor = BEACON_COLORS[world.goal.color] || '#b9dded';
  goalGroup.children.forEach((object) => object.material.color.set(goalColor));
  const expertPath = session.telemetry?.expert_path || [];
  const env = session.telemetry?.environment || {};
  const chokePoints = env.choke_points || [];
  const lidarRays = env.lidar_rays || [];
  const subZones = env.substrates?.zones || {};
  const filaments = env.plume_dynamics?.filaments || [];
  const visualKey = JSON.stringify([world.trail, expertPath, chokePoints, lidarRays, subZones, filaments, session.routes, session.activity]);
  if (visualKey !== lastWorldVisualKey) {
    lastWorldVisualKey = visualKey;
    const points = (world.trail || []).slice(-64).map((point) => new THREE.Vector3(point.x - offset, 0.035, point.z - offset));
    trailLine.geometry.dispose(); trailLine.geometry = new THREE.BufferGeometry().setFromPoints(points);
    if (pathLine) {
      const routePts = expertPath.map((point) => new THREE.Vector3(point.x - offset, 0.065, point.z - offset));
      pathLine.geometry.dispose(); pathLine.geometry = new THREE.BufferGeometry().setFromPoints(routePts);
      pathLine.material.color.set(goalColor);
    }
    if (substrateGroup) {
      disposeGroup(substrateGroup);
      const subColors = {
        viscous_agar: '#234438',
        bioelectric: '#3f2963',
        thermal_comfort: '#5e3c27',
      };
      for (const [stype, cells] of Object.entries(subZones)) {
        const color = subColors[stype];
        if (!color || !Array.isArray(cells)) continue;
        for (const cell of cells) {
          const tile = new THREE.Mesh(
            new THREE.PlaneGeometry(0.92, 0.92),
            new THREE.MeshStandardMaterial({ color, roughness: 0.8, metalness: 0.15, transparent: true, opacity: 0.75 })
          );
          tile.rotation.x = -Math.PI / 2;
          tile.position.set(cell.x - offset, -0.042, cell.z - offset);
          tile.receiveShadow = true;
          substrateGroup.add(tile);
        }
      }
    }
    if (plumeGroup) {
      disposeGroup(plumeGroup);
      if (filaments.length >= 2) {
        const filPts = filaments.map((f) => new THREE.Vector3(f.x - offset, 0.08, f.z - offset));
        const filCurve = new THREE.CatmullRomCurve3(filPts);
        const filLine = new THREE.Line(
          new THREE.BufferGeometry().setFromPoints(filCurve.getPoints(24)),
          new THREE.LineBasicMaterial({ color: '#5ee9ce', transparent: true, opacity: 0.42 })
        );
        plumeGroup.add(filLine);
        for (const f of filaments) {
          const puff = new THREE.Mesh(
            new THREE.SphereGeometry(0.08 * (1.2 - (f.fraction || 0.5) * 0.4), 8, 8),
            new THREE.MeshBasicMaterial({ color: '#5ee9ce', transparent: true, opacity: 0.35 * (1.1 - (f.fraction || 0.5) * 0.5) })
          );
          puff.position.set(f.x - offset, 0.08, f.z - offset);
          plumeGroup.add(puff);
        }
      }
    }
    if (chokeGroup) {
      disposeGroup(chokeGroup);
      for (const cp of chokePoints.slice(0, 12)) {
        const ring = new THREE.Mesh(
          new THREE.RingGeometry(0.18, 0.25, 24),
          new THREE.MeshBasicMaterial({ color: '#ad9af6', transparent: true, opacity: 0.55, side: THREE.DoubleSide })
        );
        ring.rotation.x = -Math.PI / 2;
        ring.position.set(cp.x - offset, 0.045, cp.z - offset);
        chokeGroup.add(ring);
      }
    }
    if (lidarGroup) {
      disposeGroup(lidarGroup);
      const ax = world.agent.x - offset, az = world.agent.z - offset;
      for (const ray of lidarRays) {
        const rx = ray.free_x - offset, rz = ray.free_z - offset;
        const beam = new THREE.Line(
          new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(ax, 0.18, az), new THREE.Vector3(rx, 0.12, rz)]),
          new THREE.LineBasicMaterial({ color: '#5ee9ce', transparent: true, opacity: 0.22 })
        );
        lidarGroup.add(beam);
      }
    }
    haloNodes.forEach((node, idx) => {
      const act = clip(finite(session.activity?.[idx]), 0, 2);
      const s = 0.85 + act * 0.65;
      node.scale.set(s, s, s);
    });
    haloBridges.forEach(({ dst, src, line }) => {
      const w = clip(finite(session.routes?.[dst]?.[src]), 0, 1);
      line.material.opacity = 0.06 + w * 0.78;
    });
  }
  const antTele = env.antennal_tropotaxis;
  if (antTele && leftAntennaTip && rightAntennaTip) {
    const sL = clip(finite(antTele.left_sensilla, 0), 0, 1);
    const sR = clip(finite(antTele.right_sensilla, 0), 0, 1);
    leftAntennaTip.material.emissiveIntensity = 0.3 + sL * 1.5;
    rightAntennaTip.material.emissiveIntensity = 0.3 + sR * 1.5;
  }
  const lux = finite(env.circadian?.ambient_lux, 1.0);
  if (hemiLight) hemiLight.intensity = 1.2 + lux * 1.3;
  if (keyLight) keyLight.intensity = 1.5 + lux * 2.3;
  sceneDirty = true;
  $('scene-loading').hidden = true;
}

function bindScenePointer() {
  const canvas = $('scene-canvas');
  canvas.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    pointer.down = true; pointer.id = event.pointerId; pointer.x = pointer.startX = event.clientX; pointer.y = pointer.startY = event.clientY; pointer.dragged = false;
    canvas.setPointerCapture(event.pointerId); canvas.focus({ preventScroll: true });
  });
  canvas.addEventListener('pointermove', (event) => {
    if (!pointer.down || pointer.id !== event.pointerId) return;
    const dx = event.clientX - pointer.x, dy = event.clientY - pointer.y;
    if (Math.hypot(event.clientX - pointer.startX, event.clientY - pointer.startY) > 5) pointer.dragged = true;
    if (pointer.dragged) { orbit.theta -= dx * 0.007; orbit.phi = clip(orbit.phi + dy * 0.006, 0.22, 1.3); updateCamera(); }
    pointer.x = event.clientX; pointer.y = event.clientY;
  });
  canvas.addEventListener('pointerup', (event) => {
    if (!pointer.down || pointer.id !== event.pointerId) return;
    pointer.down = false;
    if (canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId);
    if (!pointer.dragged) selectGoalAt(event.clientX, event.clientY);
  });
  canvas.addEventListener('pointercancel', () => { pointer.down = false; });
  canvas.addEventListener('wheel', (event) => { event.preventDefault(); orbit.radius = clip(orbit.radius * Math.exp(event.deltaY * 0.001), worldSize * 0.8, worldSize * 3.3); updateCamera(); }, { passive: false });
  canvas.addEventListener('contextmenu', (event) => event.preventDefault());
}

function selectGoalAt(clientX, clientY) {
  if (!webglReady || !session || writeInFlight || networkError || isStale()) return;
  const rect = $('scene-canvas').getBoundingClientRect();
  pointerVector.set((clientX - rect.left) / rect.width * 2 - 1, -(clientY - rect.top) / rect.height * 2 + 1);
  raycaster.setFromCamera(pointerVector, camera);
  const beaconHits = raycaster.intersectObjects(beaconPickables);
  if (beaconHits.length) { control({ action: 'goal', color: beaconHits[0].object.userData.beacon.color }); return; }
  const hits = raycaster.intersectObject(floorMesh);
  if (!hits.length) return;
  const offset = (session.world.size - 1) / 2;
  const x = Math.round(hits[0].point.x + offset), z = Math.round(hits[0].point.z + offset);
  if (x < 0 || z < 0 || x >= session.world.size || z >= session.world.size || (session.world.obstacles || []).some((wall) => wall.x === x && wall.z === z)) { showToast('Choose a free floor cell. Walls cannot be targets.'); return; }
  const beacon = (session.world.beacons || []).find((entry) => entry.x === x && entry.z === z);
  control(beacon ? { action: 'goal', color: beacon.color } : { action: 'goal', x, z });
}

async function initScene() {
  try {
    THREE = await import('/vendor/three.module.js');
    renderer = new THREE.WebGLRenderer({ canvas: $('scene-canvas'), antialias: !TEST_MODE, alpha: false, preserveDrawingBuffer: true, powerPreference: 'low-power' });
    renderer.setPixelRatio(TEST_MODE ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.35;
    scene = new THREE.Scene(); scene.background = new THREE.Color('#0b1521'); scene.fog = new THREE.Fog('#0b1521', 24, 57);
    camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
    hemiLight = new THREE.HemisphereLight('#b9e4f7', '#132f39', 2.5); scene.add(hemiLight);
    keyLight = new THREE.DirectionalLight('#d3efff', 3.8); keyLight.position.set(-5, 11, 6); keyLight.castShadow = true;
    keyLight.shadow.mapSize.set(512, 512); keyLight.shadow.camera.left = -9; keyLight.shadow.camera.right = 9; keyLight.shadow.camera.top = 9; keyLight.shadow.camera.bottom = -9; keyLight.shadow.normalBias = 0.03; scene.add(keyLight);
    const fill = new THREE.DirectionalLight('#57cbbd', 1.4); fill.position.set(6, 5, -8); scene.add(fill);
    worldGroup = new THREE.Group(); scene.add(worldGroup);
    raycaster = new THREE.Raycaster(); pointerVector = new THREE.Vector2();
    new ResizeObserver(resizeScene).observe($('scene-wrap'));
    window.addEventListener('resize', resizeScene); resizeScene(); bindScenePointer();
    $('scene-canvas').addEventListener('webglcontextlost', (event) => { event.preventDefault(); webglReady = false; webglError = 'WebGL context lost'; showError('The 3D renderer lost its graphics context. Reload to restore the view; the server session continues.'); });
    webglReady = true;
    if (session) updateWorld(session.world);
    let lastFrame = performance.now();
    function renderFrame(now) {
      requestAnimationFrame(renderFrame);
      if (!webglReady) return;
      const dt = Math.min((now - lastFrame) / 1000, 0.1); lastFrame = now;
      let moving = false;
      if (agentGroup) {
        const dx = agentTarget.x - agentGroup.position.x;
        const dz = agentTarget.z - agentGroup.position.z;
        let angle = agentTarget.angle - agentGroup.rotation.y;
        angle = Math.atan2(Math.sin(angle), Math.cos(angle));
        if (Math.hypot(dx, dz) > 1e-3 || Math.abs(angle) > 1e-3) {
          const easing = (reducedMotion || TEST_MODE) ? 1 : 1 - Math.exp(-dt * 15);
          agentGroup.position.x += dx * easing;
          agentGroup.position.z += dz * easing;
          agentGroup.rotation.y += angle * easing;
          moving = true;
        }
      }
      if (!sceneDirty && !moving) return;
      sceneDirty = false;
      // Visual interpolation only. Server inference/training never runs here.
      renderer.render(scene, camera);
    }
    requestAnimationFrame(renderFrame);
  } catch (error) {
    webglError = error.message || String(error);
    $('scene-loading').querySelector('strong').textContent = 'The 3D renderer is unavailable';
    $('scene-loading').querySelector('span:last-child').textContent = 'WebGL and the bundled local Three.js files are required. Session controls and chat remain available.';
    showError(`3D view: ${webglError}`);
  }
}

window.render_game_to_text = () => JSON.stringify({
  mode: !session ? 'connecting' : networkError ? 'disconnected' : isStale() ? 'stale' : session.running ? 'running' : 'paused',
  coordinates: 'integer cells; origin northwest; x east/right, z south/down; y vertical; actions 0 north, 1 east, 2 south, 3 west',
  connected: !networkError && !isStale(), renderer: webglReady ? 'three-webgl' : webglError ? 'unavailable' : 'loading', test_mode: TEST_MODE,
  running: session?.running ?? null, learning: session?.learning ?? null, busy: writeInFlight,
  world: session?.world ?? null, steps: session?.steps ?? null, updates: session?.updates ?? null,
  goals_reached: session?.goals_reached ?? null, episodes: session?.episodes ?? null,
  last_loss: session?.last_loss ?? null, policy_accuracy: session?.policy_accuracy ?? null,
  last_action: session?.last_action ?? null, last_action_source: session?.last_action_source ?? null,
  navigation: session?.navigation ?? null,
  backend: session?.backend || 'local-memory-and-control', facts: session?.facts || {},
  latest_chat: session?.chat?.slice(-2) || [], checkpoints: session?.checkpoints?.map((entry) => entry.name) || [],
  last_saved: session?.last_saved ?? null, error: $('error-banner').hidden ? null : $('error-message').textContent,
});

let testAdvanceQueue = Promise.resolve();
let testAdvanceRemainderMs = 0;
window.advanceTime = (ms) => {
  if (!TEST_MODE) return Promise.resolve(window.render_game_to_text());
  // Test requests are serialized, bounded, and paused before explicit stepping.
  testAdvanceQueue = testAdvanceQueue.catch(() => {}).then(async () => {
    if (!Number.isFinite(ms) || ms < 0 || ms > 10000) throw new Error('advanceTime expects 0–10000 milliseconds.');
    while (writeInFlight) await new Promise((resolve) => setTimeout(resolve, 15));
    if (!session) {
      const state = await fetchJSON('/api/state'); applySnapshot(state);
    }
    if (session.running && !await control({ action: 'pause' })) throw new Error('Could not pause the test session.');
    const intervalMs = Math.max(1, finite(session.runtime?.interval_seconds, 0.25) * 1000);
    testAdvanceRemainderMs += ms;
    const steps = Math.min(32, Math.floor(testAdvanceRemainderMs / intervalMs));
    if (steps > 0) {
      testAdvanceRemainderMs -= steps * intervalMs;
      if (!await control({ action: 'step', steps })) throw new Error('Could not advance the test session.');
    }
    if (agentGroup) { agentGroup.position.x = agentTarget.x; agentGroup.position.z = agentTarget.z; agentGroup.rotation.y = agentTarget.angle; }
    if (renderer && webglReady) renderer.render(scene, camera);
    return window.render_game_to_text();
  });
  return testAdvanceQueue;
};

makeSourceRows();
initCompassDial();
bindControls();
updateControls();
initScene();
poll();
loadEvaluation();
setInterval(() => { updateConnectivity(); renderEvaluation(); }, 1000);
